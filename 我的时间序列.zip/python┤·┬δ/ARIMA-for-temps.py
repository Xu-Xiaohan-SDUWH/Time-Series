import pandas as pd
from ARIMA import ARMA_model, tsplot, diff_func, reduction
import matplotlib.pyplot as plt

# read_data
data = pd.read_excel("dataset/global_temps.xlsx", index_col=0)

# difference
D_data, first_values = diff_func(data["temp"], 1)
tsplot(D_data, lags=10)

# ARIMA(0, 1, 3)
p = 0
q = 3
time_series_restored = ARMA_model(D_data, (p, q))

# reduction
reduction = reduction(time_series_restored, first_values)
# plot
plt.plot(reduction, label="ARIMA")
plt.plot(data, label="origin")
plt.legend()
plt.show()
