import pandas as pd
import sys
import matplotlib.pyplot as plt
import statsmodels.api as sm
import statsmodels.tsa.api as smt
from statsmodels.tsa.stattools import adfuller as adf
from statsmodels.tsa.stattools import arma_order_select_ic
from statsmodels.stats.diagnostic import acorr_ljungbox
from statsmodels.tsa.arima_model import ARMA
from statsmodels.graphics.api import qqplot
import numpy as np


def judge_series(data):
    # ADF检验
    dftest = adf(data)
    dfoutput = pd.Series(dftest[0:4], index=['Test Statistic','p-value','#Lags Used','Number of Observations Used'])
    stationarity = 1
    random = 1
    for key, value in dftest[4].items():
        dfoutput['Critical Value (%s)'%key] = value
        if dftest[0] > value:
                stationarity = 0
    print("是否平稳(1/0): %d" % (stationarity))
    # 纯随机性检验（白噪声检验）
    if stationarity == 1:
        p_value = acorr_ljungbox(data, lags=1)
        if p_value[1][0] < 0.05:      # 拒绝原假设
            random = 0
        print("是否具有纯随机性(1/0):", 0 if random == 0 else 1)
    return stationarity, random


def tsplot(y, lags=20, title='', figsize=(15, 8)):
    fig = plt.figure(figsize=figsize)

    ts_ax = fig.add_subplot(2, 2, 1)
    y.plot(ax=ts_ax)
    plt.xticks(rotation=30)
    ts_ax.set_title(title)

    hist_ax = fig.add_subplot(2, 2, 2)
    y.plot(ax=hist_ax, kind='hist', bins=20)
    hist_ax.set_title('Histogram')

    acf_ax = fig.add_subplot(2, 2, 3)
    smt.graphics.plot_acf(y, lags=lags, ax=acf_ax)

    pacf_ax = fig.add_subplot(2, 2, 4)
    smt.graphics.plot_pacf(y, lags=lags, ax=pacf_ax)


def determinate_order(timeseries,maxlag):
    best_p = 0
    best_q = 0
    best_bic = sys.maxsize
    for p in np.arange(maxlag):
        for q in np.arange(maxlag):
            model = ARMA(timeseries, order=(p, q))
            try:
                results_ARMA = model.fit(disp=-1)
            except:
                continue
            bic = results_ARMA.bic
            if bic < best_bic:
                best_p = p
                best_q = q
                best_bic = bic
        # print('第{}次完成...'.format(p + 1))
    return best_p, best_q


def ARMA_model(train, order):
    arma_model = ARMA(train, order).fit(disp=-1)  # 激活模型
    plt.plot(arma_model.predict(), 'k', label="ARMA")
    plt.plot(train, 'r--', label="origin")
    plt.legend(loc=0, ncol=1)
    plt.show()
    print(arma_model.summary())
    print('RMSE: %.4f' % np.sqrt(sum((arma_model.predict() - train) ** 2) / train.size))

    # 模型检验
    resid = arma_model.resid    # 残差
    # 利用QQ图检验残差是否满足正态分布
    plt.figure(figsize=(12, 8))
    qqplot(resid, line='q', fit=True)
    plt.show()
    # 利用D-W检验,检验残差的自相关性
    print('D-W检验值为{}'.format(sm.stats.durbin_watson(resid.values)))  # 接近2：无相关性
    return arma_model

