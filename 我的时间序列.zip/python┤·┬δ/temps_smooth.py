import pandas as pd
import matplotlib.pyplot as plt
from statsmodels.tsa.holtwinters import ExponentialSmoothing
import warnings

warnings.filterwarnings("ignore")
data = pd.read_excel('dataset/global_temps.xlsx', index_col=0)

model = ExponentialSmoothing(data, seasonal='additive', seasonal_periods=12).fit()
pred = model.predict(start=data.index[0], end=data.index[-1])

# plot
plt.plot(data, 'r--', label="origin")
plt.plot(pred, 'b', label="predict")
plt.legend()
plt.show()
