import pandas as pd
import numpy as np
import warnings
import itertools
import statsmodels.tsa.api as smt
import matplotlib.pyplot as plt
from statsmodels.tsa.stattools import adfuller as adf
from statsmodels.graphics.api import qqplot
from statsmodels.stats.diagnostic import acorr_ljungbox
import statsmodels.api as sm


warnings.filterwarnings("ignore")
plt.rcParams["font.sans-serif"] = ["SimHei"]   # 用来正常显示中文标签
plt.rcParams["axes.unicode_minus"] = False     # 用来正常显示负号


# 数据检测
def judge_series(data):
    # ADF检验
    dftest = adf(data)
    dfoutput = pd.Series(dftest[0:4], index=['Test Statistic','p-value','#Lags Used','Number of Observations Used'])
    stationarity = 1
    random = 1
    for key, value in dftest[4].items():
        dfoutput['Critical Value (%s)'%key] = value
        if dftest[0] > value:
                stationarity = 0
    print("是否平稳(1/0): %d" % (stationarity))
    # 纯随机性检验（白噪声检验）
    if stationarity == 1:
        p_value = acorr_ljungbox(data, lags=1)
        if p_value[1][0] < 0.05:      # 拒绝原假设
            random = 0
        print("是否具有纯随机性(1/0):", 0 if random == 0 else 1)
    return stationarity, random


def tsplot(y, lags=20, title='', figsize=(15, 8)):
    fig = plt.figure(figsize=figsize)

    ts_ax = fig.add_subplot(2, 2, 1)
    y.plot(ax=ts_ax)
    plt.xticks(rotation=30)
    ts_ax.set_title(title)

    hist_ax = fig.add_subplot(2, 2, 2)
    y.plot(ax=hist_ax, kind='hist', bins=20)
    hist_ax.set_title('Histogram')

    acf_ax = fig.add_subplot(2, 2, 3)
    smt.graphics.plot_acf(y, lags=lags, ax=acf_ax)

    pacf_ax = fig.add_subplot(2, 2, 4)
    smt.graphics.plot_pacf(y, lags=lags, ax=pacf_ax)


# 2、遍历得到最优阶数
def optimal_parameter(d, D, m, data):
    Qs = range(0, 3)
    qs = range(0, 3)
    Ps = range(0, 3)
    ps = range(0, 3)
    # 遍历所有组合
    parameters = itertools.product(ps, qs, Ps, Qs)
    parameters_list = list(parameters)
    # list参数列表
    print('parameters_list:{}'.format(parameters_list))
    print(len(parameters_list))

    best_aic = float("inf")
    best_param = ()
    for parameters in parameters_list:
        try:
            model = sm.tsa.statespace.SARIMAX(data, order=(parameters[0], d, parameters[1]),
                                              seasonal_order=(parameters[2], D, parameters[3], m)).fit(disp=-1)
        except ValueError:
            print('wrong parameters:', parameters)
            continue

        aic = model.aic
        if aic < best_aic:
            best_aic = aic
            best_param = parameters
    return best_param


# print(optimal_parameter(1, 1, 12, data[u"Passengers"]))  # (2,1,1,2)


def SARIMA_model(train, order, seasonal_order):
    show = pd.DataFrame()
    show['origin'] = train
    sarima_model = sm.tsa.statespace.SARIMAX(train, trend='n', order=order,
                                             seasonal_order=seasonal_order).fit(disp=-1)  # 激活模型
    print(sarima_model.summary())
    show['pred'] = sarima_model.predict()
    show[['origin', 'pred']].plot(figsize=(12, 8))
    print('RMSE: %.4f' % np.sqrt(sum((show['pred'] - show['origin']) ** 2) / show['origin'].size))

    # 模型检验
    resid = sarima_model.resid    # 残差
    # 利用QQ图检验残差是否满足正态分布
    plt.figure(figsize=(12, 8))
    qqplot(resid, line='q', fit=True)
    plt.show()
    # 利用D-W检验,检验残差的自相关性
    print('D-W检验值为{}'.format(sm.stats.durbin_watson(resid.values)))  # 接近2：无相关性


