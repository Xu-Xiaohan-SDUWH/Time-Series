import pandas as pd
import warnings
import arch
import matplotlib.pyplot as plt

warnings.filterwarnings("ignore")
plt.rcParams["font.sans-serif"] = ["SimHei"]
plt.rcParams["axes.unicode_minus"] = False

# read_data
data = pd.read_excel('dollar.xlsx', index_col=0)
data["diff1"] = data.diff().dropna()
data["diff1"].plot(label="diff1")
data["dollar"].plot(label="origin")
plt.legend(loc=0, ncol=1)
plt.show()

# AR(1)-GARCH(1, 1)
model = arch.univariate.arch_model(data["dollar"], mean="AR", lags=1)    # mean:AR(1)
res = model.fit(update_freq=0)
print(res.summary())

res.conditional_volatility.plot(figsize=(12, 5), color='r')
plt.title("条件方差")
plt.show()

# forecast_plot
forecasts = res.forecast(horizon=1, start=1, method='simulation')
plt.plot(forecasts.mean.iloc[:, 0], 'r', label="AR-GARCH")
plt.plot(data["dollar"], 'b:', label="origin")
plt.legend(loc=0, ncol=1)
plt.show()
