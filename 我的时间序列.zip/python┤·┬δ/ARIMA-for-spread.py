import pandas as pd
from ARIMA import ARMA_model, tsplot, diff_func, reduction
import matplotlib.pyplot as plt

# read_data
data = pd.read_csv("dataset/interest_rates.csv", index_col=0)

# difference
D_data, first_values = diff_func(data["rate"], 1)
tsplot(D_data, lags=10)

# ARIMA(1, 1, 0)
time_series_restored1 = ARMA_model(D_data, (1, 0))

# reduction
reduction1 = reduction(time_series_restored1, first_values)
# plot
plt.plot(reduction1, label="ARIMA")
plt.plot(data, label="origin")
plt.legend()
plt.show()

# ARIMA(0, 1, 1)
time_series_restored2 = ARMA_model(D_data, (0, 1))

# reduction
reduction2 = reduction(time_series_restored2, first_values)
# plot
plt.plot(reduction2, label="ARIMA")
plt.plot(data, label="origin")
plt.legend()
plt.show()
