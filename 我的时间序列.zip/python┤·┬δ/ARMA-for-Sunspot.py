import pandas as pd
import matplotlib.pyplot as plt
from ARMA import determinate_order, ARMA_model, tsplot
import warnings

warnings.filterwarnings("ignore")

# read_data
data = pd.read_excel("dataset/sunspots.xlsx", index_col=0)

# plot
tsplot(data["sunspot"])
plt.show()

# determinate order
order = determinate_order(data["sunspot"], maxlag=5)

# model
ARMA_model = ARMA_model(data["sunspot"], order)

# predict
predict = ARMA_model.predict(start=0, end=350)
predict.index = predict.index + 1700
plt.plot(predict, 'g', label="predict")
plt.plot(data, 'r--', label="origin")
plt.legend(loc=0, ncol=1)
plt.show()
