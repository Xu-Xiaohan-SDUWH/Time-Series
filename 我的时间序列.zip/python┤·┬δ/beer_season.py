from Seasonality import judge_series, optimal_parameter, SARIMA_model, tsplot
import pandas as pd
import matplotlib.pyplot as plt
from statsmodels.tsa.seasonal import seasonal_decompose

# 读取数据
data = pd.read_excel('dataset/beer.xlsx', index_col=0)
data.plot()

# 数据分解
decomposition = seasonal_decompose(data["销量"], freq=12)
decomposition.plot()

# 消除趋势项, 确定d
D_data = data.diff().dropna()
D_data.columns = [u"一阶差分"]

# 季节差分, 确定D
D_data = D_data.diff(12).dropna()
D_data.columns = [u"一阶差分&12步差分"]

# 检验是否平稳
judge_series(D_data[u"一阶差分&12步差分"])
tsplot(D_data[u"一阶差分&12步差分"])


order = (0,1,0,1)
SARIMA_model(data["销量"],(order[0],1,order[1]),(order[2],1,order[3],4))